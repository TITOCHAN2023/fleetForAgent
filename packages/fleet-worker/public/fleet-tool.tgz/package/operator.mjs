import { OFFICIAL_PLUGIN_CATALOG as GENERATED_PLUGIN_CATALOG, PLUGIN_REGISTRY_SOURCE } from "./official-plugins.generated.mjs";
import { createFileTransferPeerConfig } from "./file-transfer-contract.mjs";

/**
 * MCP operator surface. Last-used is process-local by default. Only an
 * explicit saveState adapter opts in to a caller-selected checkpoint.
 * Never create implicit hub_sessions, ~/.fleet or workspace state here.
 */

export const FLEET_VERSION = "0.6.3";
export const CLI_CONTROL_FINGERPRINT = "fleet-cli-v1";

export function createCliRpc(rawRpc) {
  return (path, body) => rawRpc(path, body, { fingerprint: CLI_CONTROL_FINGERPRINT });
}

export { PLUGIN_REGISTRY_SOURCE };
export const OFFICIAL_PLUGIN_CATALOG = GENERATED_PLUGIN_CATALOG;

function immutableCopy(value) {
  if (Array.isArray(value)) return Object.freeze(value.map(immutableCopy));
  if (value && typeof value === "object") {
    return Object.freeze(Object.fromEntries(Object.entries(value).map(([key, child]) => [key, immutableCopy(child)])));
  }
  return value;
}

export function installManifest(plugin) {
  return immutableCopy({
    schema_version: plugin.schema_version,
    id: plugin.id,
    name: plugin.name,
    version: plugin.version,
    publisher: plugin.publisher,
    license: plugin.license,
    description: plugin.description.en,
    repository: plugin.repository,
    actions: plugin.actions,
    approval_actions: plugin.approval_actions,
    runtime: plugin.runtime || "task",
    action_specs: plugin.action_specs || {},
    peer_protocols: plugin.peer_protocols || [],
    artifacts: plugin.artifacts,
  });
}

// Backward-compatible install manifests. Catalog-only entries live in
// OFFICIAL_PLUGIN_CATALOG and are never sent to a device.
export const OFFICIAL_PLUGINS = Object.freeze(
  OFFICIAL_PLUGIN_CATALOG.filter((plugin) => plugin.installable).map(installManifest),
);

export function officialPlugin(id) {
  return OFFICIAL_PLUGINS.find((plugin) => plugin.id === String(id || "").trim()) || null;
}

export function publicOfficialPlugins() {
  return immutableCopy(OFFICIAL_PLUGIN_CATALOG.map((plugin) => ({
    schema_version: plugin.schema_version,
    id: plugin.id,
    order: plugin.order,
    name: plugin.name,
    version: plugin.version,
    publisher: plugin.publisher,
    license: plugin.license,
    repository: plugin.repository,
    homepage: plugin.homepage,
    categories: plugin.categories,
    description: plugin.description.en,
    descriptions: plugin.description,
    installable: plugin.installable,
    actions: plugin.actions,
    approval_actions: plugin.approval_actions,
    runtime: plugin.runtime || "task",
    action_specs: plugin.action_specs || {},
    peer_protocols: plugin.peer_protocols || [],
    platforms: plugin.artifacts.map(({ os, arch }) => ({ os, arch })),
  })));
}

/** MCP-process fingerprint. HTTP header only — never a tool argument. */
export const FLEET_OPERATOR_HEADER = "X-Fleet-Operator";

/** MCP-call wait budget only. Not a kill timeout. Hosts cancel tools at ~60s. */
export const WAIT_MAX_MS = 30_000;
/** get_result omitted/0: instant snapshot. */
export const WAIT_DEFAULT_MS = 0;
/** run omitted wait_ms: block like other exec MCPs, then ticket if still going. */
export const RUN_WAIT_DEFAULT_MS = WAIT_MAX_MS;
export const WAIT_TOOL_DEFAULT_MS = WAIT_MAX_MS;
export const WAIT_POLL_MS = 100;

export const MISSING_DEVICE_MESSAGE =
  "device_id required — pass device_id or call set_computer";

/** Trailer on wrapped /bin/sh -c runs. Process-memory cwd only — not env persistence. */
export const CWD_MARK = "__FLEET_META__";

/** POSIX single-quote wrap. Do not interpolate the path. */
export function shQuote(value) {
  return `'${String(value).replace(/'/g, `'\\''`)}'`;
}

export const MCP_INSTRUCTIONS =
  "Fleet: remote Windows/Linux/macOS machines via a cloud hub. list_computers, then set_computer (or pass device_id). run waits up to 30s; if the text is still running, call wait — do not run again. After a lost response or session restart, use recover_session/get_result to inspect actual device state. Unknown is not failure or permission to retry; never rerun automatically. Recovery restores handles and observations, not shell variables or dead processes. Official plugin execution and software changes follow the target Agent permit: off refuses, ask prompts locally, allow runs without another click; poll get_plugin_task with its corr. start_file_transfer creates direct-only file transfer; Tool endpoints require this local stdio process, while device-to-device also works through remote MCP. Hub tokens are flt_1 values minted in website Settings. Stdio uses Fleet-OAEP; remote /mcp uses Streamable HTTP and /mcp/sse keeps classic SSE compatibility.";

export function buildPrompts() {
  return [
    {
      name: "hub_token",
      description: "How to generate or reset a Fleet hub token in Settings, and what reset does to old keys.",
    },
    {
      name: "hub_token_anatomy",
      description: "How a flt_1 hub token is composed (prefix, signed payload, RSA-2048) and how Fleet-OAEP is used instead of Bearer.",
    },
  ];
}

export function getPrompt(name) {
  if (name === "hub_token") {
    return {
      description: "Generate or reset a hub token",
      messages: [
        {
          role: "user",
          content: {
            type: "text",
            text: [
              "Generate or reset a Fleet hub token on the website Settings page, not through this MCP server.",
              "",
              "- Sign in with Google or X (cookie session).",
              "- Settings → Generate token (first time) or Reset token (replaces the key).",
              "- Plaintext is shown once. Copy FLEET_TOKEN now. FLEET_URL is the site origin.",
              "- Reset revokes the old key first, sends a signed notice, then closes every live device WebSocket and direct RTC session. Re-paste the new token on every Agent and MCP client.",
              "- Do not put the token in git or wrangler [vars].",
            ].join("\n"),
          },
        },
      ],
    };
  }
  if (name === "hub_token_anatomy") {
    return {
      description: "flt_1 token composition",
      messages: [
        {
          role: "user",
          content: {
            type: "text",
            text: [
              "A Fleet hub token is flt_1.<payload>.<sig> (RSA-2048).",
              "",
              "- payload JSON, signed RSA-PSS-SHA256: v, aud, kid, pub, iat, sec",
              "- aud is HUB_ORIGIN (https://fleet.ginfo.cc), never the HTTP Host header",
              "- Agents and stdio MCP GET /v1/challenge?kid=… then send Authorization: Fleet-OAEP <kid>.<oaep({sec,nonce})>",
              "- Remote /mcp uses Streamable HTTP with Authorization: Bearer <token> and an opaque Mcp-Session-Id response header",
              "- Classic /mcp/sse sends Bearer once to open a server-side session; its random message URL contains no token",
              "- Reset mints a new keypair; the old kid will not complete the handshake",
            ].join("\n"),
          },
        },
      ],
    };
  }
  return null;
}

export function wrapSessionCommand(command, cwd) {
  const lines = [
    "__fleet_ec=0",
    `trap '__fleet_ec=$?; printf "\\n${CWD_MARK} %s %s\\n" "$__fleet_ec" "$(pwd)"; exit "$__fleet_ec"' EXIT`,
  ];
  if (cwd) lines.push(`cd ${shQuote(cwd)} || exit $?`);
  lines.push(String(command));
  return lines.join("\n");
}

export function stripSessionMeta(stdout) {
  const text = stdout == null ? "" : String(stdout);
  const re = new RegExp(`(?:^|\\r?\\n)${CWD_MARK} (\\d+) ([^\\r\\n]*)\\s*$`);
  const m = text.match(re);
  if (!m) return { stdout: text, cwd: null, exit: null };
  const exit = Number(m[1]);
  const cwd = m[2] || null;
  let cleaned = text.slice(0, m.index);
  if (cleaned.endsWith("\r")) cleaned = cleaned.slice(0, -1);
  return { stdout: cleaned, cwd, exit: Number.isFinite(exit) ? exit : null };
}

export function clampWaitMs(ms) {
  const n = Number(ms);
  if (!Number.isFinite(n) || n <= 0) return 0;
  return Math.min(WAIT_MAX_MS, n);
}

export function parseOptionalMs(value, name) {
  if (value == null || value === "") return null;
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n)) throw new Error(`${name} must be a number`);
  return n;
}

export function isFinishedResult(row) {
  if (!row || typeof row !== "object") return false;
  if (row.status === "pending" || row.status === "running") return false;
  if (row.status === "done" || row.status === "unknown") return true;
  return row.ok !== undefined || row.exit_code !== undefined;
}

const SHELL_RESULT_TOOLS = new Set(["run", "get_result", "wait"]);

function nonemptyText(value) {
  if (value == null) return "";
  return String(value);
}

/** One UUID per MCP stdio process. Do not read FLEET_OPERATOR or any model-filled env. */
export function newOperatorFingerprint() {
  return crypto.randomUUID();
}

export async function operationCorr(fingerprint, requestId) {
  if (typeof requestId !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(requestId)) {
    throw new Error("request_id must be a UUID");
  }
  const hash = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`${fingerprint || ""}\0${requestId.toLowerCase()}`));
  const hex = Array.from(new Uint8Array(hash).slice(0, 16), (b) => b.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
}

export async function operationInput(command) {
  const hash = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(command));
  return Array.from(new Uint8Array(hash), (b) => b.toString(16).padStart(2, "0")).join("");
}

export function fleetHubHeaders({ token, authorization, fingerprint, extra } = {}) {
  const headers = {
    authorization: authorization || (token ? `Bearer ${token}` : ""),
    "content-type": "application/json",
    ...extra,
  };
  if (fingerprint) headers[FLEET_OPERATOR_HEADER] = fingerprint;
  return headers;
}

export function isFleetDev(env = {}) {
  const v = String(env.FLEET_DEV ?? "").trim().toLowerCase();
  return v === "1" || v === "true" || v === "yes";
}

/** Strip `--dev` and set FLEET_DEV=1. Same env the MCP clients use. */
export function applyCliDevFlag(args, env = process.env) {
  const out = [];
  let dev = false;
  for (const a of args) {
    if (a === "--dev") dev = true;
    else out.push(a);
  }
  if (dev) env.FLEET_DEV = "1";
  return out;
}

function numOrZero(n) {
  const v = Number(n);
  return Number.isFinite(v) ? v : 0;
}

function stampOrNull(row, key) {
  if (!row || typeof row !== "object" || row[key] == null) return null;
  return row[key];
}

function rowTime(row) {
  if (!row || typeof row !== "object") return null;
  if (row.t != null && Number.isFinite(Number(row.t))) return Number(row.t);
  if (row.T != null && Number.isFinite(Number(row.T))) return Number(row.T);
  return null;
}

export function emptyDevStamps() {
  return {
    hub_recv_t: null,
    hub_reply_t: null,
    hub_ms: null,
    device_enqueue_t: null,
    device_done_t: null,
    device_run_ms: null,
  };
}

function isoOrNull(ms) {
  return Number.isFinite(Number(ms)) ? new Date(Number(ms)).toISOString() : null;
}

export function finalizeHop(hop, path, row) {
  const t_out = hop?.t_out;
  const t_in = hop?.t_in;
  const wait_ms = numOrZero(hop?.wait_ms ?? hop?.gap_ms);
  return {
    path: path || hop?.path || "?",
    t_out,
    t_in,
    t_out_iso: hop?.t_out_iso || isoOrNull(t_out),
    t_in_iso: hop?.t_in_iso || isoOrNull(t_in),
    send_ms: numOrZero(hop?.send_ms),
    wait_ms,
    gap_ms: numOrZero(hop?.gap_ms ?? wait_ms),
    recv_ms: numOrZero(hop?.recv_ms),
    total_ms: numOrZero(
      hop?.total_ms ?? (Number.isFinite(Number(t_in)) && Number.isFinite(Number(t_out)) ? Number(t_in) - Number(t_out) : 0),
    ),
    http_status: hop?.http_status ?? null,
    split: hop?.split || "body",
    status: hop?.status ?? hopStatus(row),
  };
}

export function formatHopLine(h) {
  const path = String(h?.path || "?").padEnd(16);
  return `# hop ${path} out=${h.t_out} in=${h.t_in} send=${numOrZero(h.send_ms)}ms wait=${numOrZero(h.wait_ms)}ms recv=${numOrZero(h.recv_ms)}ms total=${numOrZero(h.total_ms)}ms`;
}

export function formatDevTrailer(dev) {
  if (!dev || typeof dev !== "object") return "";
  const hops = Array.isArray(dev.hops) ? dev.hops : [];
  const lines = ["# fleet-dev"];
  for (const h of hops) lines.push(formatHopLine(h));
  const parts = [];
  if (dev.run_ms != null) parts.push(`run_ms=${dev.run_ms}`);
  if (dev.client_run_gap_ms != null) parts.push(`client_gap=${dev.client_run_gap_ms}ms`);
  parts.push(`poll=${dev.poll_count ?? 0}`);
  if (numOrZero(dev.sleep_ms) > 0) parts.push(`sleep=${dev.sleep_ms}ms`);
  parts.push(`total=${numOrZero(dev.total_ms)}ms`);
  lines.push(`# ${parts.join(" ")}`);
  return lines.join("\n");
}

/**
 * fetch split as tightly as undici allows.
 * send_ms = JSON serialize only (write vs TTFB cannot be split).
 * wait_ms / gap_ms = serialize-done → response headers (TTFB, includes the TCP write).
 * recv_ms = headers → JSON parsed.
 * split=headers.
 */
export async function measureHubFetch(url, init = {}, clocks = {}) {
  const wall = clocks.wall || Date.now;
  const perf =
    clocks.perf ||
    (() => (typeof performance !== "undefined" && performance.now ? performance.now() : Date.now()));
  const t_out = wall();
  const p0 = perf();
  const serialized = init.body == null ? "" : typeof init.body === "string" ? init.body : JSON.stringify(init.body);
  const pSent = perf();
  const res = await fetch(url, { ...init, body: serialized === "" && init.body == null ? init.body : serialized });
  const pHeaders = perf();
  const json = await res.json();
  const pEnd = perf();
  const t_in = wall();
  const wait_ms = Math.max(0, pHeaders - pSent);
  return {
    ok: res.ok,
    status: res.status,
    json,
    hop: finalizeHop(
      {
        t_out,
        t_in,
        t_out_iso: isoOrNull(t_out),
        t_in_iso: isoOrNull(t_in),
        send_ms: Math.max(0, pSent - p0),
        wait_ms,
        gap_ms: wait_ms,
        recv_ms: Math.max(0, pEnd - pHeaders),
        total_ms: Math.max(0, t_in - t_out),
        http_status: res.status,
        split: "headers",
      },
      clocks.path,
    ),
  };
}

const RESULT_TRANSPORT = Symbol("fleet.result.transport");
const DEVICE_TRANSPORT_PATHS = new Set([
  "/v1/heartbeat",
  "/v1/run",
  "/v1/get_result",
  "/v1/read_screen",
  "/v1/type",
  "/v1/desktop_screenshot",
  "/v1/desktop_action",
  "/v1/plugin",
  "/v1/plugin_result",
]);

function normalizeTransport(value) {
  return value === "rtc" || value === "ws" ? value : null;
}

export function isDeviceTransportPath(path) {
  return DEVICE_TRANSPORT_PATHS.has(path);
}

/** Internal RPC wrapper. Transport provenance never enters the Fleet v1 envelope. */
export function wrapTransportRpc(raw, transport) {
  const normalized = normalizeTransport(transport);
  if (!normalized) return raw;
  if (raw && typeof raw === "object" && raw.__fleetTimed) {
    return {
      __fleetTransportRpc: true,
      json: raw.json,
      hop: raw.hop,
      transport: normalized,
    };
  }
  return {
    __fleetTransportRpc: true,
    json: raw,
    hop: null,
    transport: normalized,
  };
}

export function unwrapTimedRpc(raw) {
  if (raw && typeof raw === "object" && raw.__fleetTransportRpc) {
    return {
      json: raw.json,
      hop: raw.hop ?? null,
      transport: normalizeTransport(raw.transport),
    };
  }
  if (raw && typeof raw === "object" && raw.__fleetTimed) {
    return { json: raw.json, hop: raw.hop, transport: null };
  }
  return { json: raw, hop: null, transport: null };
}

function markResultTransport(out, transport) {
  const normalized = normalizeTransport(transport);
  if (normalized && out && (typeof out === "object" || typeof out === "function")) {
    Object.defineProperty(out, RESULT_TRANSPORT, {
      value: normalized,
      enumerable: false,
      configurable: false,
      writable: false,
    });
  }
  return out;
}

/** Per-result lookup avoids a process-global "last transport" race between MCP calls. */
export function resultTransport(out) {
  if (!out || (typeof out !== "object" && typeof out !== "function")) return null;
  return normalizeTransport(out[RESULT_TRANSPORT]);
}

export function fleetResultMeta(out) {
  const transport = resultTransport(out);
  return transport ? { fleet_transport: transport } : null;
}

/** MCP content text. Shell tools (run / get_result / wait) are human output, not JSON.stringify of the envelope. */
export function formatMcpText(name, out, env = {}) {
  let text;
  if (!SHELL_RESULT_TOOLS.has(name)) {
    if (out == null) text = "";
    else if (typeof out === "string") text = out;
    else if (typeof out === "object") {
      const { timing: _timing, dev: _dev, image_b64: _img, ...rest } = out;
      text = JSON.stringify(rest);
    } else text = JSON.stringify(out);
  } else if (!out || typeof out !== "object") {
    text = out == null ? "" : String(out);
  } else if (out.status === "unknown") {
    text = out.error || "Execution outcome unknown. Inspect the device before retrying; do not rerun automatically.";
  } else if (!isFinishedResult(out)) {
    text = "still running";
  } else {
    const stdout = nonemptyText(out.stdout);
    const err = nonemptyText(out.error) || nonemptyText(out.stderr);
    const code = out.exit_code;
    const failed = out.ok === false || (code != null && Number(code) !== 0);
    if (!failed) {
      text = stdout;
      if (err !== "") {
        text = text === "" ? err : (text.endsWith("\n") ? text : text + "\n") + err;
      }
    } else {
      const lines = [];
      if (stdout !== "") lines.push(stdout.endsWith("\n") ? stdout.slice(0, -1) : stdout);
      if (code != null && String(code) !== "") lines.push(`exit_code: ${code}`);
      if (err !== "") lines.push(err);
      text = lines.join("\n");
    }
  }
  if (out?.output_unavailable) text += `${text ? "\n" : ""}[Output unavailable after device restart; completion receipt retained.]`;
  if (out?.receipt_error) text += `${text ? "\n" : ""}[Warning: ${out.receipt_error}]`;
  if (!isFleetDev(env)) return text;
  const trailer = formatDevTrailer(out && typeof out === "object" ? out.dev : null);
  if (!trailer) return text;
  if (text === "") return trailer;
  return (text.endsWith("\n") ? text : text + "\n") + trailer;
}

export function deviceMismatchMessage(corr, owner, got) {
  return `corr ${corr} belongs to device ${owner}, not ${got}`;
}

function trimId(value) {
  return typeof value === "string" ? value.trim() : "";
}

function withDevice(row, deviceId) {
  return { ...row, device_id: deviceId };
}

function runningSnapshot(row, corr, deviceId) {
  const extra = row && typeof row === "object" ? { ...row } : {};
  delete extra.status;
  delete extra.isError;
  return { ...extra, corr, status: "running", device_id: deviceId };
}

function waitMsSchema({ defaultMs, role }) {
  return {
    type: "number",
    default: defaultMs,
    minimum: 0,
    maximum: WAIT_MAX_MS,
    description:
      `${role} MCP-call wait budget in milliseconds. Default ${defaultMs}. Capped at ${WAIT_MAX_MS} (30s) so the host cannot cancel with -32001 (clients ~60s). wait_ms never kills the remote command. A still-running reply is not an error — do not re-issue run; long-poll with get_result(wait_ms) or wait(wait_ms). Do not spam wait_ms=0.`,
  };
}

export function buildTools() {
  const deviceId = { type: "string", description: "Target machine id or account-local alias. Optional after set_computer or a prior explicit device_id in this process. FLEET_DEVICE_ID is a start-of-process default only." };
  return [
    {
      name: "list_computers",
      description: "List machines in this hub account (id, alias, name, os, online, lastSeen, agentVer). Never returns IPs. Call this first, then set_computer.",
      inputSchema: { type: "object", properties: {} },
    },
    {
      name: "get_computer",
      description:
        "Status of one machine from the same catalog as list_computers: id, alias, online, lastSeen, agentVer, name, os. Accepts a real id or account-local alias. Never returns IPs. Optional device_id after set_computer or a prior explicit device_id in this process.",
      inputSchema: {
        type: "object",
        properties: { device_id: deviceId },
      },
    },
    {
      name: "heartbeat",
      description:
        "Ask a connected agent to report presence now. The hub stores lastSeen and agentVer from the reply so a just-upgraded client shows the new version. 409 if the device is offline or does not heartbeat. Optional device_id after set_computer. Do not invent a device id.",
      inputSchema: {
        type: "object",
        properties: { device_id: deviceId },
      },
    },
    {
      name: "run",
      description:
        "Run a shell command on a fleet machine. Default wait_ms 30000. wait_ms=0 returns immediately while the job keeps running. If the result is still running, call wait — do not run the same command again. wait_ms never kills the remote process.",
      inputSchema: {
        type: "object",
        required: ["command"],
        properties: {
          device_id: deviceId,
          command: { type: "string" },
          request_id: { type: "string", description: "Optional stable UUID for recovery-capable devices. Reuse ONLY with the identical command after inspecting an uncertain outcome. Never generates a new execution for an existing receipt." },
          wait_ms: waitMsSchema({
            defaultMs: RUN_WAIT_DEFAULT_MS,
            role: "Optional. Omitted waits up to 30s; 0 is the immediate ticket.",
          }),
        },
      },
    },
    {
      name: "recover_session",
      description: "Read-only recovery: inspect this operator's saved device, operation result and pane. Never reruns a command or recreates an environment. Stdio restart recovery requires a unique FLEET_SESSION_PATH configured before the original run.",
      inputSchema: { type: "object", properties: { device_id: deviceId } },
    },
    {
      name: "get_result",
      description:
        "Snapshot this process's live session. wait_ms omitted/0 is instant; wait_ms>0 long-polls (max 30s). still running is not an error — poll again, do not re-run.",
      inputSchema: {
        type: "object",
        properties: {
          device_id: deviceId,
          wait_ms: waitMsSchema({ defaultMs: WAIT_DEFAULT_MS, role: "Optional." }),
        },
      },
    },
    {
      name: "wait",
      description:
        "Block until this process's live session finishes or wait_ms elapses (default 30s). Does not kill the remote command. still running → poll again, do not re-run.",
      inputSchema: {
        type: "object",
        properties: {
          device_id: deviceId,
          wait_ms: waitMsSchema({ defaultMs: WAIT_TOOL_DEFAULT_MS, role: "Explicit block." }),
        },
      },
    },
    {
      name: "read_screen",
      description: "Snapshot this process's pane current frame (rendered grid on a live PTY). Does not attach or stream.",
      inputSchema: {
        type: "object",
        properties: { device_id: deviceId },
      },
    },
    {
      name: "type",
      description:
        "Fire-and-forget keystrokes into this process's pane stdin. keys is a string (newlines become Enter/CR on the live PTY). Optional key is a named press like ssh_press: enter, ctrl+c, up. ctrl+c sends 0x03 and SIGINT to the foreground process group.",
      inputSchema: {
        type: "object",
        properties: {
          device_id: deviceId,
          keys: { type: "string", description: "Literal keystrokes. Still accepted. Newlines become CR on the live PTY." },
          key: { type: "string", description: "Named key (enter, ctrl+c, up, f5, ...). Optional; do not invent a sixth tool." },
        },
      },
    },
    {
      name: "set_computer",
      description:
        "Resolve a real device id or account-local alias, then remember the immutable id for later calls in this MCP process only. Not written to disk or other clients.",
      inputSchema: {
        type: "object",
        required: ["device_id"],
        properties: { device_id: { type: "string" } },
      },
    },
    {
      name: "get_current_computer",
      description: "Show this process's last-used device, last cwd, and FLEET_DEVICE_ID start default.",
      inputSchema: { type: "object", properties: {} },
    },
    {
      name: "desktop_screenshot",
      description:
        "Capture the device primary display as a JPEG. Coordinates are pixels of this image, origin top-left. Requires get_computer.caps to include computer_use (Windows/macOS/Linux screenshot from Agent 0.3.0). Not the pane tool read_screen. Optional device_id after set_computer.",
      inputSchema: {
        type: "object",
        properties: {
          device_id: deviceId,
          max_width: { type: "number", description: "Viewport long-edge cap. Agent clamps to 320–1920, default 1280." },
          max_height: { type: "number" },
        },
      },
    },
    {
      name: "desktop_action",
      description:
        "HID on the primary display. x,y required for click/move/drag/scroll (pixels of the last screenshot, top-left origin, not native). left_click_drag also needs x2,y2. Actions: screenshot, left_click, right_click, double_click, middle_click, mouse_move, left_click_drag, scroll, type, key, wait. Optional frame_id from the screenshot. Requires computer_use. Not the pane tool type. Optional device_id after set_computer.",
      inputSchema: {
        type: "object",
        properties: {
          device_id: deviceId,
          action: {
            type: "string",
            description: "screenshot | left_click | right_click | double_click | middle_click | mouse_move | left_click_drag | scroll | type | key | wait",
          },
          x: { type: "number" },
          y: { type: "number" },
          x2: { type: "number" },
          y2: { type: "number" },
          text: { type: "string" },
          key: { type: "string" },
          keys: { description: "Named keys array, same as key joined with +" },
          scroll_x: { type: "number" },
          scroll_y: { type: "number" },
          duration_ms: { type: "number" },
          frame_id: { type: "string" },
        },
        required: ["action"],
      },
    },
    {
      name: "list_official_plugins",
      description: "List the signed-by-registry official Fleet plugins available to install. This is local catalog data and does not contact a device.",
      inputSchema: { type: "object", properties: {} },
    },
    {
      name: "list_plugins",
      description: "Ask a remote Fleet Agent for its installed plugins. Returns a corr ticket; call get_plugin_task with that corr.",
      inputSchema: { type: "object", properties: { device_id: deviceId } },
    },
    {
      name: "install_plugin",
      description: "Install or upgrade one official plugin by registry id. The hub supplies the approved URL and SHA-256; arbitrary URLs are not accepted. The target Agent permit applies: off refuses, ask prompts locally, allow auto-authorizes. Returns a corr ticket.",
      inputSchema: {
        type: "object",
        required: ["plugin_id"],
        properties: { device_id: deviceId, plugin_id: { type: "string", description: "Official id from list_official_plugins, for example fleet.acp." } },
      },
    },
    {
      name: "uninstall_plugin",
      description: "Remove an installed official plugin and its private plugin data from the device under the target Agent permit. Returns a corr ticket.",
      inputSchema: {
        type: "object",
        required: ["plugin_id"],
        properties: { device_id: deviceId, plugin_id: { type: "string" } },
      },
    },
    {
      name: "invoke_plugin",
      description: "Invoke an action exposed by an installed official plugin. Device permit rules apply. Returns a corr ticket; poll get_plugin_task.",
      inputSchema: {
        type: "object",
        required: ["plugin_id", "action"],
        properties: {
          device_id: deviceId,
          plugin_id: { type: "string" },
          action: { type: "string" },
          input: { type: "object", additionalProperties: true },
          timeout_seconds: { type: "number", minimum: 1, maximum: 3600 },
        },
      },
    },
    {
      name: "get_plugin_task",
      description: "Read an install, uninstall, inventory, or plugin-action ticket. waiting_approval/running means poll this same corr; never submit the action again.",
      inputSchema: {
        type: "object",
        required: ["corr"],
        properties: { device_id: deviceId, corr: { type: "string" } },
      },
    },
    {
      name: "start_file_transfer",
      description:
        "Start one direct-only file transfer under this Fleet account. Each endpoint is kind=tool or kind=device. Tool paths belong to this local stdio process; remote Worker MCP only supports device-to-device. Each device endpoint follows its Agent permit: off refuses, ask prompts locally, allow auto-authorizes. File bytes never pass through Worker and a failed direct connection never falls back to relay.",
      inputSchema: {
        type: "object",
        required: ["source", "target"],
        properties: {
          source: {
            type: "object",
            required: ["kind", "path"],
            properties: {
              kind: { type: "string", enum: ["tool", "device"] },
              device_id: { type: "string", description: "Required when kind=device." },
              path: { type: "string", description: "Absolute source file path on that endpoint." },
            },
          },
          target: {
            type: "object",
            required: ["kind", "directory"],
            properties: {
              kind: { type: "string", enum: ["tool", "device"] },
              device_id: { type: "string", description: "Required when kind=device." },
              directory: { type: "string", description: "Absolute destination directory on that endpoint. Existing files are never overwritten." },
            },
          },
        },
      },
    },
    {
      name: "get_file_transfer",
      description: "Read one file transfer state and byte progress. Does not expose SDP, ICE candidates, paths, IPs, or tickets.",
      inputSchema: {
        type: "object",
        required: ["transfer_id"],
        properties: { transfer_id: { type: "string" } },
      },
    },
    {
      name: "cancel_file_transfer",
      description: "Cancel a file transfer. Explicit cancel removes partial receiver data; a network interruption keeps resumable partial data.",
      inputSchema: {
        type: "object",
        required: ["transfer_id"],
        properties: { transfer_id: { type: "string" } },
      },
    },
    {
      name: "configure_acp",
      description: "Configure a named local ACP-agent stdio command for the installed fleet.acp plugin. This does not install that third-party ACP agent. Device permit rules apply; returns a corr ticket.",
      inputSchema: {
        type: "object",
        required: ["command"],
        properties: {
          device_id: deviceId,
          profile: { type: "string", default: "default" },
          command: { type: "string", description: "ACP-compatible executable already installed on the remote device." },
          args: { type: "array", items: { type: "string" } },
        },
      },
    },
    {
      name: "delegate_to_acp",
      description: "Delegate one task to a configured ACP v1 agent on the remote machine. It runs initialize, session/new, and session/prompt and returns the streamed agent text through get_plugin_task. Nested ACP tool permissions reject by default; permission_mode=allow_once selects only an explicit allow_once option.",
      inputSchema: {
        type: "object",
        required: ["cwd", "prompt"],
        properties: {
          device_id: deviceId,
          profile: { type: "string", default: "default" },
          cwd: { type: "string", description: "Absolute workspace path on the remote device." },
          prompt: { type: "string" },
          additional_directories: { type: "array", items: { type: "string" } },
          permission_mode: { type: "string", enum: ["reject", "allow_once"], default: "reject" },
          timeout_seconds: { type: "number", minimum: 1, maximum: 3600, default: 900 },
        },
      },
    },
  ];
}

export function desktopMcpRow(row) {
  if (!row || typeof row !== "object") {
    return { ok: false, status: "error", code: "bad_request", error: "empty desktop reply", isError: true };
  }
  const out = { ...row, isError: row.ok === false || row.isError === true };
  return out;
}

async function desktopCall(trace, path, body, callRpc, signal) {
  try {
    const row = await callRpc(trace, path, body, { signal });
    return desktopMcpRow(row);
  } catch (err) {
    if (err && typeof err === "object" && err.json) {
      return desktopMcpRow({
        ok: false,
        status: "error",
        code: err.json.code || "http_error",
        error: err.json.error || err.message,
        missing: err.json.missing,
        agentVer: err.json.agentVer,
        os: err.json.os,
        http_status: err.status,
        isError: true,
      });
    }
    throw err;
  }
}

function waitWithSignal(promise, signal) {
  if (!signal) return promise;
  if (signal.aborted) return Promise.reject(signal.reason || new Error("tool call cancelled"));
  return new Promise((resolve, reject) => {
    const done = (callback, value) => {
      signal.removeEventListener("abort", onAbort);
      callback(value);
    };
    const onAbort = () => done(reject, signal.reason || new Error("tool call cancelled"));
    signal.addEventListener("abort", onAbort, { once: true });
    Promise.resolve(promise).then(
      (value) => done(resolve, value),
      (error) => done(reject, error),
    );
  });
}

function hopStatus(row) {
  if (!row || typeof row !== "object") return undefined;
  if (row.status != null) return row.status;
  if (row.ok === false) return "error";
  return undefined;
}

export function createOperator({
  rpc,
  fileTransfer,
  env = {},
  state = {},
  fingerprint = "",
  saveState,
  sleep = (ms) => new Promise((r) => setTimeout(r, ms)),
  now = () => Date.now(),
} = {}) {
  if (typeof rpc !== "function") throw new Error("rpc required");

  let lastUsed = trimId(state.lastUsed) || null;
  let lastCwd = trimId(state.lastCwd) || null;
  const envDefault = trimId(env.FLEET_DEVICE_ID) || null;
  let envResolved = null;
  const corrByDevice = new Map();
  const requestByDevice = new Map(Object.entries(state.requestByDevice || {}));
  const cwdByDevice = new Map(Object.entries(state.cwdByDevice || {}));
  if (lastUsed && lastCwd && !cwdByDevice.has(lastUsed)) cwdByDevice.set(lastUsed, lastCwd);
  const canonicalIds = new Set();
  const recoveryDevices = new Set();
  const snapshotState = () => ({ lastUsed, lastCwd, envDefault, corrByDevice: Object.fromEntries(corrByDevice), cwdByDevice: Object.fromEntries(cwdByDevice), requestByDevice: Object.fromEntries(requestByDevice) });
  const checkpoint = () => { if (saveState) saveState(snapshotState()); };
  if (state.corrByDevice && typeof state.corrByDevice === "object" && !Array.isArray(state.corrByDevice)) {
    for (const [rawDeviceId, rawCorr] of Object.entries(state.corrByDevice)) {
      const deviceId = trimId(rawDeviceId);
      const corr = trimId(rawCorr);
      if (deviceId && corr) corrByDevice.set(deviceId, corr);
    }
  }
  const fleetDev = isFleetDev(env);
  const tools = buildTools();

  function newTrace() {
    return { hops: [], started: now(), sleep_ms: 0, startedRow: null, transport: null };
  }

  async function callRpc(trace, path, body, { signal } = {}) {
    const payload = fleetDev && body && typeof body === "object" ? { ...body, dev: true } : body;
    const t_out = now();
    const raw = await rpc(path, payload, { signal });
    const t_in = now();
    const { json: row, hop: measured, transport } = unwrapTimedRpc(raw);
    if (trace && transport) trace.transport = transport;
    if (!trace) return row;
    const hop = finalizeHop(
      measured || {
        t_out,
        t_in,
        send_ms: 0,
        wait_ms: Math.max(0, t_in - t_out),
        recv_ms: 0,
        total_ms: Math.max(0, t_in - t_out),
        http_status: null,
        split: "body",
      },
      path,
      row,
    );
    trace.hops.push(hop);
    if (path === "/v1/run" && !trace.startedRow) trace.startedRow = row;
    return row;
  }

  async function canonicalDevice(reference, trace, signal) {
    const ref = trimId(reference);
    if (!ref) throw new Error("device_id required");
    const row = await callRpc(trace, "/v1/get_computer", { device_id: ref }, { signal });
    const id = trimId(row?.id);
    if (!id) throw new Error(`device not found: ${ref}`);
    canonicalIds.add(id);
    if (row.caps?.includes("operation_recovery_v1")) recoveryDevices.add(id);
    else recoveryDevices.delete(id);
    return { id, row };
  }

  function withDev(out, trace) {
    let result = out;
    if (fleetDev && trace) {
      const hops = trace.hops.slice();
      const runHop = hops.find((h) => h.path === "/v1/run");
      const getHops = hops.filter((h) => h.path === "/v1/get_result");
      const startT = rowTime(trace.startedRow);
      const doneT = rowTime(out);
      const run_ms = startT != null && doneT != null ? doneT - startT : null;
      const client_run_gap_ms = runHop && getHops[0] ? getHops[0].t_in - runHop.t_out : null;
      result = {
        ...out,
        dev: {
          hops,
          poll_count: getHops.length,
          sleep_ms: trace.sleep_ms || 0,
          total_ms: Math.max(0, now() - trace.started),
          run_ms,
          client_run_gap_ms,
          ...emptyDevStamps(),
          hub_recv_t: stampOrNull(out, "hub_recv_t"),
          hub_reply_t: stampOrNull(out, "hub_reply_t"),
          hub_ms: stampOrNull(out, "hub_ms"),
          device_enqueue_t: startT,
          device_done_t: doneT,
          device_run_ms: run_ms,
        },
      };
    }
    return markResultTransport(result, trace?.transport);
  }

  function currentDevice() {
    if (lastUsed) return { device_id: lastUsed, source: "last_used" };
    if (envDefault) return { device_id: envResolved || envDefault, source: "env" };
    return { device_id: null, source: "none" };
  }

  function resolveDevice(args = {}) {
    const explicit = trimId(args.device_id);
    if (explicit) {
      lastUsed = explicit;
      return explicit;
    }
    if (lastUsed) return lastUsed;
    if (envDefault) return envDefault;
    throw new Error(MISSING_DEVICE_MESSAGE);
  }

  async function targetDevice(args, trace, signal, { fresh = false } = {}) {
    const explicit = trimId(args?.device_id);
    const source = explicit ? "explicit" : lastUsed ? "last_used" : "env";
    const reference = explicit || lastUsed || envResolved || envDefault;
    if (!reference) throw new Error(MISSING_DEVICE_MESSAGE);
    if (!fresh && canonicalIds.has(reference)) {
      if (source === "env") envResolved = reference;
      else lastUsed = reference;
      return { id: reference, row: null };
    }
    const resolved = await canonicalDevice(reference, trace, signal);
    if (reference !== resolved.id && corrByDevice.has(reference)) {
      if (!corrByDevice.has(resolved.id)) corrByDevice.set(resolved.id, corrByDevice.get(reference));
      corrByDevice.delete(reference);
    }
    if (source === "env") envResolved = resolved.id;
    else lastUsed = resolved.id;
    checkpoint();
    return resolved;
  }

  function decorateResult(row, deviceId) {
    let out = withDevice(row, deviceId);
    if (typeof out.stdout === "string") {
      const meta = stripSessionMeta(out.stdout);
      out = { ...out, stdout: meta.stdout };
      if (meta.cwd) { lastCwd = meta.cwd; cwdByDevice.set(deviceId, meta.cwd); }
    }
    if (isFinishedResult(out)) out = { ...out, cwd: cwdByDevice.get(deviceId) || null };
    checkpoint();
    return out;
  }

  function rememberCorr(deviceId, value) {
    const corr = trimId(value);
    if (corr) { corrByDevice.set(deviceId, corr); checkpoint(); }
    return corr;
  }

  function currentCorr(deviceId) {
    return corrByDevice.get(deviceId) || "";
  }

  async function peekResult(deviceId, trace, waitMs = 0, corr = "", signal) {
    const body = { device_id: deviceId };
    const ticket = corr || currentCorr(deviceId);
    if (ticket) body.corr = ticket;
    if (ticket === currentCorr(deviceId) && requestByDevice.has(deviceId)) body.request_id = requestByDevice.get(deviceId);
    if (waitMs > 0) body.wait_ms = waitMs;
    const row = await callRpc(trace, "/v1/get_result", body, { signal });
    if (!currentCorr(deviceId)) rememberCorr(deviceId, row?.corr);
    return decorateResult(row, deviceId);
  }

  async function waitForResult(deviceId, timeoutMs, trace, corr, hooks) {
    const budget = clampWaitMs(timeoutMs);
    const startedAt = now();
    const deadline = startedAt + budget;
    let ticket = trimId(corr) || currentCorr(deviceId);
    let snapshot = await peekResult(deviceId, trace, 0, ticket, hooks?.signal);
    ticket = trimId(snapshot?.corr) || ticket;
    if (isFinishedResult(snapshot) || budget <= 0) {
      return isFinishedResult(snapshot) ? snapshot : runningSnapshot(snapshot, ticket, deviceId);
    }
    while (now() < deadline) {
      if (isFinishedResult(snapshot)) return snapshot;
      if (hooks?.isCancelled?.()) return runningSnapshot(snapshot, ticket, deviceId);
      const left = deadline - now();
      if (left <= 0) break;
      hooks?.onProgress?.({ progress: budget - left, total: budget });
      const sl = Math.min(WAIT_POLL_MS, left);
      if (trace) trace.sleep_ms += sl;
      await waitWithSignal(sleep(sl), hooks?.signal);
      snapshot = await peekResult(deviceId, trace, 0, ticket, hooks?.signal);
      ticket = trimId(snapshot?.corr) || ticket;
    }
    if (isFinishedResult(snapshot)) return snapshot;
    return runningSnapshot(snapshot, ticket, deviceId);
  }

  async function execOnDevice(deviceId, command, waitMs, trace, hooks, requestId) {
    const body = { device_id: deviceId, command };
    if (requestId != null) await operationCorr(fingerprint, requestId);
    if (requestId != null && !recoveryDevices.has(deviceId)) throw new Error("Device does not support operation recovery; update the Agent before using request_id");
    if (recoveryDevices.has(deviceId) && (requestId != null || saveState)) {
      body.request_id = requestId ?? crypto.randomUUID();
      // Remote MCP owns the operator fingerprint in its transport adapter.
      // Retain its request proof too; the acknowledged corr arrives below.
      requestByDevice.set(deviceId, body.request_id);
      // Persist BEFORE dispatch, so a lost HTTP acknowledgement is recoverable.
      if (fingerprint) rememberCorr(deviceId, await operationCorr(fingerprint, body.request_id));
    } else {
      requestByDevice.delete(deviceId);
    }
    const t0 = now();
    const started = await callRpc(trace, "/v1/run", body, { signal: hooks?.signal });
    const expectedInput = body.request_id ? await operationInput(command) : "";
    const checked = (row) => {
      if (expectedInput && row?.input_hash && row.input_hash !== expectedInput) throw new Error("request_id already used with different command; original operation was not rerun");
      return row;
    };
    checked(started);
    const corr = rememberCorr(deviceId, started?.corr);
    if (waitMs <= 0) {
      return withDevice({ ...started, corr, status: started?.status ?? "running" }, deviceId);
    }
    const finished = decorateResult({ ...started, corr }, deviceId);
    if (isFinishedResult(started) || isFinishedResult(finished)) return finished;
    const left = waitMs - Math.max(0, now() - t0);
    if (left <= 0) return runningSnapshot(started, corr, deviceId);
    return checked(await waitForResult(deviceId, left, trace, corr, hooks));
  }

  async function callTool(name, rawArgs, hooks = {}) {
    const args = rawArgs && typeof rawArgs === "object" ? rawArgs : {};
    const trace = newTrace();
    if (hooks.signal?.aborted || hooks.isCancelled?.()) throw new Error("tool call cancelled");

    if (name === "list_computers") {
      const row = await callRpc(trace, "/v1/list_computers", {}, { signal: hooks.signal });
      return withDev(row, trace);
    }

    if (name === "get_computer") {
      const { id: deviceId, row } = await targetDevice(args, trace, hooks.signal, { fresh: true });
      return withDev(withDevice(row, deviceId), trace);
    }

    if (name === "heartbeat") {
      const { id: deviceId } = await targetDevice(args, trace, hooks.signal);
      const row = await callRpc(trace, "/v1/heartbeat", { device_id: deviceId }, { signal: hooks.signal });
      return withDev(withDevice(row, deviceId), trace);
    }

    if (name === "set_computer") {
      const { id: deviceId, row } = await targetDevice(args, trace, hooks.signal, { fresh: true });
      return { ok: true, device_id: deviceId, alias: trimId(row?.alias) || null };
    }

    if (name === "get_current_computer") {
      const cur = currentDevice();
      return {
        device_id: cur.device_id,
        last_used: lastUsed,
        env_default: envDefault,
        source: cur.source,
        cwd: cwdByDevice.get(cur.device_id) || null,
      };
    }

    if (name === "run") {
      const command = args.command == null ? "" : String(args.command);
      if (!command) throw new Error("command required");
      const { id: deviceId } = await targetDevice(args, trace, hooks.signal);
      const waitMs = clampWaitMs(parseOptionalMs(args.wait_ms, "wait_ms") ?? RUN_WAIT_DEFAULT_MS);
      return withDev(await execOnDevice(deviceId, command, waitMs, trace, hooks, args.request_id), trace);
    }

    if (name === "recover_session") {
      const { id: deviceId, row } = await targetDevice(args, trace, hooks.signal, { fresh: true });
      const corr = currentCorr(deviceId);
      if (!corr) return { status: "empty", device_id: deviceId, error: "No saved operation in this session; no command was dispatched." };
      const result = await peekResult(deviceId, trace, 0, corr, hooks.signal);
      const screen = await callRpc(trace, "/v1/read_screen", { device_id: deviceId, corr }, { signal: hooks.signal });
      return withDev({ device: row, device_id: deviceId, corr, cwd: cwdByDevice.get(deviceId) || null, result, pane: screen.screen ?? null, replayed: false }, trace);
    }

    if (name === "get_result") {
      const { id: deviceId } = await targetDevice(args, trace, hooks.signal);
      const waitMs = clampWaitMs(parseOptionalMs(args.wait_ms, "wait_ms") ?? WAIT_DEFAULT_MS);
      if (waitMs <= 0) return withDev(await peekResult(deviceId, trace, 0, "", hooks.signal), trace);
      return withDev(await waitForResult(deviceId, waitMs, trace, undefined, hooks), trace);
    }

    if (name === "wait") {
      const { id: deviceId } = await targetDevice(args, trace, hooks.signal);
      const waitMs = clampWaitMs(parseOptionalMs(args.wait_ms, "wait_ms") ?? WAIT_TOOL_DEFAULT_MS);
      return withDev(await waitForResult(deviceId, waitMs, trace, undefined, hooks), trace);
    }

    if (name === "read_screen") {
      const { id: deviceId } = await targetDevice(args, trace, hooks.signal);
      const body = { device_id: deviceId };
      const corr = currentCorr(deviceId);
      if (corr) body.corr = corr;
      const row = await callRpc(trace, "/v1/read_screen", body, { signal: hooks.signal });
      return withDev(withDevice(row, deviceId), trace);
    }

    if (name === "type") {
      if (args.keys == null && args.key == null) throw new Error("keys or key required");
      const { id: deviceId } = await targetDevice(args, trace, hooks.signal);
      const body = { device_id: deviceId };
      if (args.keys != null) body.keys = args.keys;
      if (args.key != null && String(args.key) !== "") body.key = String(args.key);
      if (body.keys == null && body.key) body.keys = body.key;
      const corr = currentCorr(deviceId);
      if (corr) body.corr = corr;
      const row = await callRpc(trace, "/v1/type", body, { signal: hooks.signal });
      return withDev(withDevice(row, deviceId), trace);
    }

    if (name === "desktop_screenshot") {
      const { id: deviceId } = await targetDevice(args, trace, hooks.signal);
      const body = { device_id: deviceId };
      if (args.max_width != null) body.max_width = args.max_width;
      if (args.max_height != null) body.max_height = args.max_height;
      const row = await desktopCall(trace, "/v1/desktop_screenshot", body, callRpc, hooks.signal);
      return withDev(withDevice(row, deviceId), trace);
    }

    if (name === "desktop_action") {
      const { id: deviceId } = await targetDevice(args, trace, hooks.signal);
      const body = { device_id: deviceId, action: args.action };
      for (const k of ["x", "y", "x2", "y2", "text", "key", "keys", "scroll_x", "scroll_y", "duration_ms", "frame_id"]) {
        if (args[k] != null) body[k] = args[k];
      }
      if (body.key && body.keys) {
        // key wins when both are set
        delete body.keys;
      }
      const row = await desktopCall(trace, "/v1/desktop_action", body, callRpc, hooks.signal);
      return withDev(withDevice(row, deviceId), trace);
    }

    if (name === "list_official_plugins") {
      return { registry: PLUGIN_REGISTRY_SOURCE, plugins: publicOfficialPlugins() };
    }

    if (name === "get_plugin_task") {
      const { id: deviceId } = await targetDevice(args, trace, hooks.signal);
      const corr = trimId(args.corr);
      if (!corr) throw new Error("corr required");
      const row = await callRpc(trace, "/v1/plugin_result", { device_id: deviceId, corr }, { signal: hooks.signal });
      return withDev(withDevice(row, deviceId), trace);
    }

    if (name === "start_file_transfer") {
      let source = args.source && typeof args.source === "object" ? args.source : null;
      let target = args.target && typeof args.target === "object" ? args.target : null;
      if (!source || !target) throw new Error("source and target required");
      const canonical = new Map();
      const canonicalEndpoint = async (endpoint) => {
        if (endpoint.kind !== "device") return endpoint;
        const reference = trimId(endpoint.device_id);
        if (!reference) return endpoint;
        let deviceId = canonical.get(reference);
        if (!deviceId) {
          deviceId = (await canonicalDevice(reference, trace, hooks.signal)).id;
          canonical.set(reference, deviceId);
        }
        return { ...endpoint, device_id: deviceId };
      };
      source = await canonicalEndpoint(source);
      target = await canonicalEndpoint(target);
      if (fileTransfer?.start) {
        if (hooks.signal?.aborted || hooks.isCancelled?.()) throw new Error("tool call cancelled");
        return fileTransfer.start({ source, target }, { signal: hooks.signal });
      }
      if (source.kind === "tool" || target.kind === "tool") {
        throw new Error("Tool file endpoints require the local Fleet Tool stdio/CLI process");
      }
      const sourceId = trimId(source.device_id);
      const targetId = trimId(target.device_id);
      const sourcePath = source.path == null ? "" : String(source.path).trim();
      const targetPath = target.directory == null ? "" : String(target.directory).trim();
      if (!sourceId || !targetId || !sourcePath || !targetPath) {
        throw new Error("device source/target require device_id and absolute path/directory");
      }
      const plugin = officialPlugin("fleet.transfer");
      const protocol = plugin?.peer_protocols?.find((value) => value.id === "fleet.transfer.v2");
      if (!plugin || !protocol) throw new Error("fleet.transfer.v2 is unavailable in the pinned official plugin catalog");
      const sessionId = crypto.randomUUID();
      const config = await createFileTransferPeerConfig({
        source: { kind: "device", device_id: sourceId, path: sourcePath },
        target: { kind: "device", device_id: targetId, directory: targetPath, name: target.name },
      }, { plugin, sessionId });
      if (hooks.signal?.aborted || hooks.isCancelled?.()) throw new Error("tool call cancelled");
      const row = await callRpc(trace, "/v1/plugin-peer-session/create", {
        session_id: config.session_id,
        protocol_id: config.protocol.id,
        initiator: config.initiator,
        source: config.source,
        target: config.target,
      }, { signal: hooks.signal });
      const session = row.session ?? row;
      return withDev({ ...session, transfer_id: session.session_id || sessionId }, trace);
    }

    if (name === "get_file_transfer") {
      const transferId = trimId(args.transfer_id);
      if (!transferId) throw new Error("transfer_id required");
      if (fileTransfer?.status) return fileTransfer.status(transferId, { signal: hooks.signal });
      const row = await callRpc(trace, "/v1/plugin-peer-session/status", { session_id: transferId }, { signal: hooks.signal });
      const session = row.session ?? row;
      return withDev({ ...session, transfer_id: session.session_id || transferId }, trace);
    }

    if (name === "cancel_file_transfer") {
      const transferId = trimId(args.transfer_id);
      if (!transferId) throw new Error("transfer_id required");
      if (fileTransfer?.cancel) return fileTransfer.cancel(transferId, { signal: hooks.signal });
      const current = await callRpc(trace, "/v1/plugin-peer-session/status", { session_id: transferId }, { signal: hooks.signal });
      const roundId = (current.session ?? current)?.round?.id;
      if (!roundId) throw new Error("plugin peer session has no current round");
      const row = await callRpc(trace, "/v1/plugin-peer-session/event", {
        session_id: transferId,
        round_id: roundId,
        event: "cancel",
      }, { signal: hooks.signal });
      const session = row.session ?? row;
      return withDev({ ...session, transfer_id: session.session_id || transferId }, trace);
    }

    if (["list_plugins", "install_plugin", "uninstall_plugin", "invoke_plugin", "configure_acp", "delegate_to_acp"].includes(name)) {
      const { id: deviceId } = await targetDevice(args, trace, hooks.signal);
      const body = { device_id: deviceId };
      if (name === "list_plugins") body.operation = "list";
      if (name === "install_plugin" || name === "uninstall_plugin") {
        const pluginId = trimId(args.plugin_id);
        if (!pluginId) throw new Error("plugin_id required");
        body.operation = name === "install_plugin" ? "install" : "uninstall";
        body.plugin_id = pluginId;
      }
      if (name === "invoke_plugin") {
        const pluginId = trimId(args.plugin_id);
        const action = trimId(args.action);
        if (!pluginId || !action) throw new Error("plugin_id and action required");
        Object.assign(body, { operation: "invoke", plugin_id: pluginId, action, input: args.input || {} });
        if (args.timeout_seconds != null) body.timeout_seconds = args.timeout_seconds;
      }
      if (name === "configure_acp") {
        const command = trimId(args.command);
        if (!command) throw new Error("command required");
        Object.assign(body, {
          operation: "invoke", plugin_id: "fleet.acp", action: "configure",
          input: { profile: trimId(args.profile) || "default", command, args: Array.isArray(args.args) ? args.args : [] },
        });
      }
      if (name === "delegate_to_acp") {
        const cwd = trimId(args.cwd);
        const prompt = args.prompt == null ? "" : String(args.prompt).trim();
        if (!cwd || !prompt) throw new Error("cwd and prompt required");
        Object.assign(body, {
          operation: "invoke", plugin_id: "fleet.acp", action: "delegate",
          input: {
            profile: trimId(args.profile) || "default", cwd, prompt,
            additional_directories: Array.isArray(args.additional_directories) ? args.additional_directories : [],
            permission_mode: args.permission_mode === "allow_once" ? "allow_once" : "reject",
            timeout_seconds: args.timeout_seconds == null ? 900 : args.timeout_seconds,
          },
          timeout_seconds: args.timeout_seconds == null ? 900 : args.timeout_seconds,
        });
      }
      const row = await callRpc(trace, "/v1/plugin", body, { signal: hooks.signal });
      return withDev(withDevice(row, deviceId), trace);
    }

    throw new Error(`unknown tool ${name}`);
  }

  return {
    tools,
    prompts: buildPrompts(),
    getPrompt,
    callTool,
    resolveDevice,
    currentDevice,
    getState: snapshotState,
  };
}
